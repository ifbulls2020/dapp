<?php
//000000000000
 exit();?>
a:2:{s:16:"admin_login_init";a:1:{i:0;s:23:"\addons\loginbg\Loginbg";}s:11:"config_init";a:1:{i:0;s:29:"\addons\summernote\Summernote";}}