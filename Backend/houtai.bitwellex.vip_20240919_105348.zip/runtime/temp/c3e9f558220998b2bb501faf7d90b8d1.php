<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:104:"/www/wwwroot/houtai.bitwellex.vip/crypto11.icu/public/../application/admin/view/contract_order/edit.html";i:1670261176;s:89:"/www/wwwroot/houtai.bitwellex.vip/crypto11.icu/application/admin/view/layout/default.html";i:1670261178;s:86:"/www/wwwroot/houtai.bitwellex.vip/crypto11.icu/application/admin/view/common/meta.html";i:1670261174;s:88:"/www/wwwroot/houtai.bitwellex.vip/crypto11.icu/application/admin/view/common/script.html";i:1670261174;}*/ ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
<title><?php echo (isset($title) && ($title !== '')?$title:''); ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<meta name="renderer" content="webkit">
<meta name="referrer" content="never">
<meta name="robots" content="noindex, nofollow">

<link rel="shortcut icon" href="/assets/img/favicon.ico" />
<!-- Loading Bootstrap -->
<link href="/assets/css/backend<?php echo \think\Config::get('app_debug')?'':'.min'; ?>.css?v=<?php echo \think\Config::get('site.version'); ?>" rel="stylesheet">

<?php if(\think\Config::get('fastadmin.adminskin')): ?>
<link href="/assets/css/skins/<?php echo \think\Config::get('fastadmin.adminskin'); ?>.css?v=<?php echo \think\Config::get('site.version'); ?>" rel="stylesheet">
<?php endif; ?>

<!-- HTML5 shim, for IE6-8 support of HTML5 elements. All other JS at the end of file. -->
<!--[if lt IE 9]>
  <script src="/assets/js/html5shiv.js"></script>
  <script src="/assets/js/respond.min.js"></script>
<![endif]-->
<script type="text/javascript">
    var require = {
        config:  <?php echo json_encode($config); ?>
    };
</script>

    </head>

    <body class="inside-header inside-aside <?php echo defined('IS_DIALOG') && IS_DIALOG ? 'is-dialog' : ''; ?>">
        <div id="main" role="main">
            <div class="tab-content tab-addtabs">
                <div id="content">
                    <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <section class="content-header hide">
                                <h1>
                                    <?php echo __('Dashboard'); ?>
                                    <small><?php echo __('Control panel'); ?></small>
                                </h1>
                            </section>
                            <?php if(!IS_DIALOG && !\think\Config::get('fastadmin.multiplenav') && \think\Config::get('fastadmin.breadcrumb')): ?>
                            <!-- RIBBON -->
                            <div id="ribbon">
                                <ol class="breadcrumb pull-left">
                                    <?php if($auth->check('dashboard')): ?>
                                    <li><a href="dashboard" class="addtabsit"><i class="fa fa-dashboard"></i> <?php echo __('Dashboard'); ?></a></li>
                                    <?php endif; ?>
                                </ol>
                                <ol class="breadcrumb pull-right">
                                    <?php foreach($breadcrumb as $vo): ?>
                                    <li><a href="javascript:;" data-url="<?php echo $vo['url']; ?>"><?php echo $vo['title']; ?></a></li>
                                    <?php endforeach; ?>
                                </ol>
                            </div>
                            <!-- END RIBBON -->
                            <?php endif; ?>
                            <div class="content">
                                <form id="edit-form" class="form-horizontal" role="form" data-toggle="validator" method="POST" action="">

    <div class="form-group">
        <label class="control-label col-xs-12 col-sm-2"><?php echo __('Uid'); ?>:</label>
        <div class="col-xs-12 col-sm-8">
            <input id="c-uid" data-rule="required" min="0" class="form-control" name="row[uid]" type="number" value="<?php echo htmlentities($row['uid']); ?>">
        </div>
    </div>
    <div class="form-group">
        <label class="control-label col-xs-12 col-sm-2"><?php echo __('Contract_config_id'); ?>:</label>
        <div class="col-xs-12 col-sm-8">
            <input id="c-contract_config_id" data-rule="required" min="0" data-source="contract_config/index" class="form-control selectpage" data-field="coin" name="row[contract_config_id]" type="text" value="<?php echo htmlentities($row['contract_config_id']); ?>">
        </div>
    </div>
    <div class="form-group">
        <label class="control-label col-xs-12 col-sm-2"><?php echo __('Start_time'); ?>:</label>
        <div class="col-xs-12 col-sm-8">
            <input id="c-start_time" data-rule="required" min="0" class="form-control datetimepicker" data-date-format="YYYY-MM-DD HH:mm:ss" data-use-current="true" name="row[start_time]" type="text" value="<?php echo $row['start_time']?datetime($row['start_time']):''; ?>">
        </div>
    </div>
    <div class="form-group">
        <label class="control-label col-xs-12 col-sm-2"><?php echo __('End_time'); ?>:</label>
        <div class="col-xs-12 col-sm-8">
            <input id="c-end_time" data-rule="required" min="0" class="form-control datetimepicker" data-date-format="YYYY-MM-DD HH:mm:ss" data-use-current="true" name="row[end_time]" type="text" value="<?php echo $row['end_time']?datetime($row['end_time']):''; ?>">
        </div>
    </div>
    <div class="form-group">
        <label class="control-label col-xs-12 col-sm-2"><?php echo __('Increase'); ?>:</label>
        <div class="col-xs-12 col-sm-8">
            <input id="c-increase" data-rule="required" class="form-control" step="0.0001" name="row[increase]" type="number" value="<?php echo htmlentities($row['increase']); ?>">
        </div>
    </div>
    <div class="form-group">
        <label class="control-label col-xs-12 col-sm-2"><?php echo __('Odds'); ?>:</label>
        <div class="col-xs-12 col-sm-8">
            <input id="c-odds" data-rule="required" min="0" class="form-control" step="0.0001" name="row[odds]" type="number" value="<?php echo htmlentities($row['odds']); ?>">
        </div>
    </div>
    <div class="form-group">
        <label class="control-label col-xs-12 col-sm-2"><?php echo __('Amount'); ?>:</label>
        <div class="col-xs-12 col-sm-8">
            <input id="c-amount" data-rule="required" min="0" class="form-control" step="0.000001" name="row[amount]" type="number" value="<?php echo htmlentities($row['amount']); ?>">
        </div>
    </div>
    <div class="form-group">
        <label class="control-label col-xs-12 col-sm-2"><?php echo __('Amount_unit'); ?>:</label>
        <div class="col-xs-12 col-sm-8">
            <input id="c-amount_unit" data-rule="required" class="form-control" name="row[amount_unit]" type="text" value="<?php echo htmlentities($row['amount_unit']); ?>">
        </div>
    </div>
    <div class="form-group">
        <label class="control-label col-xs-12 col-sm-2"><?php echo __('Status'); ?>:</label>
        <div class="col-xs-12 col-sm-8">
            
            <div class="radio">
            <?php if(is_array($statusList) || $statusList instanceof \think\Collection || $statusList instanceof \think\Paginator): if( count($statusList)==0 ) : echo "" ;else: foreach($statusList as $key=>$vo): ?>
            <label for="row[status]-<?php echo $key; ?>"><input id="row[status]-<?php echo $key; ?>" name="row[status]" type="radio" value="<?php echo $key; ?>" <?php if(in_array(($key), is_array($row['status'])?$row['status']:explode(',',$row['status']))): ?>checked<?php endif; ?> /> <?php echo $vo; ?></label> 
            <?php endforeach; endif; else: echo "" ;endif; ?>
            </div>

        </div>
    </div>
    <div class="form-group">
        <label class="control-label col-xs-12 col-sm-2"><?php echo __('Start_price'); ?>:</label>
        <div class="col-xs-12 col-sm-8">
            <input id="c-start_price" data-rule="required" min="0" class="form-control" step="0.000001" name="row[start_price]" type="number" value="<?php echo htmlentities($row['start_price']); ?>">
        </div>
    </div>
    <div class="form-group">
        <label class="control-label col-xs-12 col-sm-2"><?php echo __('End_price'); ?>:</label>
        <div class="col-xs-12 col-sm-8">
            <input id="c-end_price" data-rule="required" min="0" class="form-control" step="0.000001" name="row[end_price]" type="number" value="<?php echo htmlentities($row['end_price']); ?>">
        </div>
    </div>
    <div class="form-group">
        <label class="control-label col-xs-12 col-sm-2"><?php echo __('Lose_win'); ?>:</label>
        <div class="col-xs-12 col-sm-8">
                        
            <select  id="c-lose_win" data-rule="required" min="0" class="form-control selectpicker" name="row[lose_win]">
                <?php if(is_array($loseWinList) || $loseWinList instanceof \think\Collection || $loseWinList instanceof \think\Paginator): if( count($loseWinList)==0 ) : echo "" ;else: foreach($loseWinList as $key=>$vo): ?>
                    <option value="<?php echo $key; ?>" <?php if(in_array(($key), is_array($row['lose_win'])?$row['lose_win']:explode(',',$row['lose_win']))): ?>selected<?php endif; ?>><?php echo $vo; ?></option>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </select>

        </div>
    </div>
    <div class="form-group">
        <label class="control-label col-xs-12 col-sm-2"><?php echo __('Profit_loss'); ?>:</label>
        <div class="col-xs-12 col-sm-8">
            <input id="c-profit_loss" data-rule="required" class="form-control" step="0.000001" name="row[profit_loss]" type="number" value="<?php echo htmlentities($row['profit_loss']); ?>">
        </div>
    </div>
    <div class="form-group">
        <label class="control-label col-xs-12 col-sm-2"><?php echo __('Risk_mangement'); ?>:</label>
        <div class="col-xs-12 col-sm-8">
                        
            <select  id="c-risk_mangement" data-rule="required" min="0" class="form-control selectpicker" name="row[risk_mangement]">
                <?php if(is_array($riskMangementList) || $riskMangementList instanceof \think\Collection || $riskMangementList instanceof \think\Paginator): if( count($riskMangementList)==0 ) : echo "" ;else: foreach($riskMangementList as $key=>$vo): ?>
                    <option value="<?php echo $key; ?>" <?php if(in_array(($key), is_array($row['risk_mangement'])?$row['risk_mangement']:explode(',',$row['risk_mangement']))): ?>selected<?php endif; ?>><?php echo $vo; ?></option>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </select>

        </div>
    </div>
    <div class="form-group layer-footer">
        <label class="control-label col-xs-12 col-sm-2"></label>
        <div class="col-xs-12 col-sm-8">
            <button type="submit" class="btn btn-primary btn-embossed disabled"><?php echo __('OK'); ?></button>
            <button type="reset" class="btn btn-default btn-embossed"><?php echo __('Reset'); ?></button>
        </div>
    </div>
</form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="/assets/js/require<?php echo \think\Config::get('app_debug')?'':'.min'; ?>.js" data-main="/assets/js/require-backend<?php echo \think\Config::get('app_debug')?'':'.min'; ?>.js?v=<?php echo htmlentities($site['version']); ?>"></script>
    </body>
</html>
